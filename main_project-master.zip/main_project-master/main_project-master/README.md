# main_project
 prediction and detection of lung cancer
