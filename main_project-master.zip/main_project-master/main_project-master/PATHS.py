NAVBAR_PATHS = {
    'INTRODUCTION':'introduction',
    'ABOUT DATASET': 'about_dataset',
    'LUNG CANCER PREDICTION': 'prediction',
    'CNN BASED PREDICTION': 'cnn_based'
}
